public class FileHelper {
    // TODO Thursday
//    File newFile = new File(STORAGE_PATH + FILE_NAME + FILE_EXTENSION);
//    try{
//        if(! newFile.exists())
//            newFile.createNewFile();
//        FileOutputStream writer = new FileOutputStream(newFile);
//        BufferedOutputStream bos = new BufferedOutputStream(writer);
//        bos.write(content);
//        bos.close();
//    } catch(IOException e){
//        e.printStackTrace();
//    }
}
