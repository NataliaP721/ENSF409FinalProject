
public class EmailHelper {
    private String SERVER_EMAIL;
    private String SERVER_PASSWORD;
    // TODO on Friday
//    sendEmail void (Email email) {
//
//    }
}
